# gets more detail
# comes from psych package
pacman::p_load(pacman,dplyr,GGally,gglot2,ggthemes,ggvis,httr,lubridate,plotly,rio,rmarkdown,shiny,stringr,tidyr)
library(datsets)
head(iris)
p_load(psych)
p_help(psych)
p_help(psych,web=F)
#describe
describe(iris$Sepal.Length)#one quantitative variable
describe(iris)# for entire data frame

