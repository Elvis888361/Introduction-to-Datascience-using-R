#out of many variable one variavle
library(datasets)
?USJudgeRatings
head(USJudgeRatings)
data<-USJudgeRatings
x<-as.matrix(data[-12])#do all the others apart from 12
y<-data[,12]#read only 12 column
#regression with simultaneous entry
reg1<-lm(y~x)
reg1<-lm(RTEN~CONT+INTG+DMNR+DILG+CFMG+DECI+PREP+FAMI+ORAL+WRIT+PHYS,data = USJudgeRatings)
reg1#shows all the coefficient
summary(reg1)
anova(reg1)
coef(reg1)
confint(reg1)
resid(reg1)
hist(residuals(reg1))



#additional
p_load(lars,caret)
