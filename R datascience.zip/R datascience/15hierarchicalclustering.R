#modeling data example
#like with like 
#which data is like the other 
# this similarities depends on your criteria
# some crieteria include hierarchical vs setk,measures of distance,divisive vs .agglomerative
#what we are going to look at Euclidean distance,hierarchical clustering,divisive method.
library(datasets)
?mtcars
head(mtcars)
cars<-mtcars[,c(1:4,6:7,9:11)]#selects variables
head(cars)
#compute and plot clusters
hc<-cars %>%#gets car data
  dist %>%#compute distance
  hclust#compute hierarchical cluster
plot(hc)#plot dedrogram
#add boxes to plot
rect.hclust(hc,k=2,border = "grey")
rect.hclust(hc,k=3,border = "blue")
rect.hclust(hc,k=4,border = "green4")
rect.hclust(hc,k=5,border = "darkred")
