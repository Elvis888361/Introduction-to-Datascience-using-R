# less is more
#dimentioonality reduction
# steps pca two variable regression perpendicular distance collapserotate to flat
#went from 2d to 1 d and maintain important info
library(datasets)
head(mtcatrs)
head(mtcars)
cars<-mtcars[,c(1:4,6:7,9:11)]
head(cars)
#compute pca
# for entire data frame
pc<-prcomp(cars,
           center = TRUE,
           scale=TRUE)
 #to specify variables
pc<-prcomp(~mpg+cyl+disp+hp+wt+qsec+am+gear+carb,
           data=mtcars,
           center=TRUE,
           scale=TRUE)
#examine results
#get summary
summary(pc)
plot(pc)
pc
predict(pc)%>%round(2)
biplot(pc)
