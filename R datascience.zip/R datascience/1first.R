library(datasets)

head(iris)
summary(iris)
plot(iris)#plots

detach("package:datasets",unload = TRUE)
dev.off()
cat("\014") #clearing console
#Two types of packages Base Package -this are installed with R but not loaded by default
#The second one need to be downloaded installed,& loaded separately where to find them CRAN Crantastic GitHub
 #dplyr for manipulating datasets
#tidyr for cleaning up info
#stringr for working with strings
#lubridate for working with dates
#httr for working with website data
#ggvis for interactive visualisation
#ggplot2 for plotting and data visualization
#shiny for creating interactive as that you can install from website
# rio for creating r for input and output
#&rmarkdown for creating notebooks for sharing your info
#pacman  for one package to load them all
