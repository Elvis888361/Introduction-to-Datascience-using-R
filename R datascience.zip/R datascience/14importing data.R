# get data anad process quickly
# the data tao import csv TXT xlsx json
#imoting format one to use is RIO
# rio combine all of Rs import functions into one simpe utility
pacman::p_load(pacman,
               dplyr,GGally,gglot2
               ,ggthemes,ggvis,httr
               ,lubridate,plotly,rio
               ,rmarkdown,shiny,stringr
               ,tidyr)
 #not complete
install_formats()
library("rio")
browseURL("http://j.mp/2aFZUrJ")
rio_csv<-import("C:\\Users\\user\\Desktop\\ton.csv")
head(rio_csv)

rio_txt<-import("C:\\Users\\user\\Desktop\\pro.txt")
head(rio_txt)
rio_xlsx<-import("C:\\Users\\user\\Desktop\\ton.xls")
head(rio_xlsx)
#data viewer
?view

View(rio_csv)
r_csv<-read.table("C:\\Users\\user\\Desktop\\ton.csv",
                  header = TRUE,
                  sep = "\t")
read.csv("C:\\Users\\user\\Desktop\\ton.csv")
