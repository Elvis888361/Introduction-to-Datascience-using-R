#focus your analysis,choose cases,look at them more closely
#select by category or by value or by both
library(datasets)
head(iris)
hist(iris$Petal.Length)
summary(iris$Petal.Length)
summary(iris$Species)#get names and n for each species
#select by category
hist(iris$Petal.Length[iris$Species=="versicolor"],
     main = "Petal Length:versicolor")
hist(iris$Petal.Length[iris$Species=="virginica"],
     main = "Petal Length:virginica")
hist(iris$Petal.Length[iris$Species=="setosa"],
     main = "Petal Length:setosa")
#select by value
#select values of 2 which are setosa
hist(iris$Petal.Length[iris$Petal.Length<2],
     main = "Petal Length < 2")
#short virginica petals only
#using multiple selector
hist(iris$Petal.Length[iris$Species=="virginica"&
                         iris$Petal.Length<5.5],
     main = "Petal Length: Short viriginica")
#Create SUBSAmple
#leave rows or column blank to select all
i.setosa <-iris[iris$Species=="setosa",]
head(i.setosa)
summary(i.setosa$Petal.Length)
hist(i.setosa$Petal.Length)
