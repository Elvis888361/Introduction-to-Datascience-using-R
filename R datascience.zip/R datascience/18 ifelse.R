x=5
y=1
# if condition
if(x>y){
  print("x is larger")
}
#if else condition
if(x<y){
  print("x is lastrger")
}else{
  print("x is smaller")
}
# if elseif else
if(x<y){
  print("x is lastrger")
}else if(x==y){
  print("Equals")
}else{
  print("x is smaller")
}
# for loops
for (value in 1:5){print(value)}
vec=c(1,2,3)
for (value in vec){print(value)}
#while loop
value=1
while (value<5) {print(value)

    value=value+1
    }
