#basic graphs plot command
#basic x-y
library(datasets)
head(iris)
?plot#help command?
plot(iris$Species)#categories variable 
#it will tell you there is three categories of iris 
plot(iris$Petal.Length)#Quantitative variable
#brings a scatter shows distribution in a scatter graph
plot(iris$Species,iris$Petal.Length)#cat x quant both categories in scatter 
plot(iris$Petal.Length,iris$Petal.Width)#quant pair
#clear plot
plot(iris)#Entire data frame
#enter plot show dot plot for each species ,it is able to adapt
plot(iris$Petal.Length,iris$Petal.Width,
     col="#cc0000",#color
     pch=19,#solid circle
     main="Iris :petal Length vs. Petal width",
     xlab="Petal Length",#label
     ylab="Petal Width")#shows clear picture of a plot

plot(cos,0,2*pi) #this shows cosign adding formulas in the plot command

plot(exp,1,5)#shows exponnential graph
plot(dnorm,-3,+3)#shows density over nominal graph
plot(dnorm,-3,+3,
     col="#cc0000",
     lwd=5,
     main="Standard Norminal Distribution",
     xlab="z-scores",
     ylab="Density")#making the graph more smarter
#quick impression of the data

