library(datasets)
library(datasets)
?mtcars
head(mtcars)
 #bar chart
barplot((mtcars$cyl))#doesnt work
#beginning to create we need to reformat it
#first create a sammary
cylinders<-table(mtcars$cyl)#creates table
barplot(cylinders)#bar chat
plot(cylinders)# will create a line chart


