#data types data structure
#data types : numeric character,logical,complex,$raw
#data structure vector,data frAME,matrix/array,list
#vector is one number in a 1d array
#in vector all same data type
#Rs basic data object
#matrics two dimensions
#same length ,same data class columns not named they are called by indexss
#Array -identical to a matrix but 3 or more dimensiion
#data frame- can have vector of multiple type,all same length
#closest R analogue to spreadsheet,Special function
#list most flexible,ordered collection of elements any class ,lebgthor structure,can include lists
#coercion is changing a data object from one type to anoher for example changing adouble to an integer, matrix to data frame
#numeric data type
n1 <- 15 #Double precison by default
n1
typeof(n1)

n2 <-1.5
n2
typeof(n2)
#character datatype
c1<-"c"
c1
typeof(c1)

c2 <-"a string of text"
c2
typeof(c2)
#logical
l1<-TRUE
l1
typeof(l1)

l2<-F
l2
typeof(l2)
#data structures
#1 vectors
v1<-c(1,2,3,4,5)#concancinate or cmbine
v1
is.vector(v1)

v2<-c("a","b","c")
v2
is.vector(v2)

v3<-c(TRUE,TRUE,FALSE,FALSE,TRUE)
v3
is.vector(v3)

# 2 matrixs
m1<-matrix(c(T,T,F,F,T,F),nrow = 2)
m1

m2<-matrix(c("a","b","c","d"),nrow = 2,byrow = T)
m2

#3array
a1<-array(c(1:24),c(4,3,2))
a1

#4 data frames
#can combine vectors of different type
vNumeric <-c(1,2,3)
vCharacter<-c("a","b","c")
vLogical<-c(T,F,T)

dfa<-cbind(vNumeric,vCharacter,vLogical)
dfa

df<- as.data.frame(cbind(vNumeric,vCharacter,vLogical))
df

#5 list
o1<-c(1,2,3)
o2<-c("a","b","c","d")
o3<-c(T,F,T,T,F)

list1<-list(o1,o2,o3)
list1

# list within list
list2<-list(o1,o2,o3,list1)
list2

#coercing types
# automatic coercing
#goes to "least restrictivedata types
(coerce1<-c(1,"b",TRUE))
typeof(coerce1)
#coerce number to integer
(coerce2<-5)

typeof(coerce2)
(coerce3<-as.integer(5))
typeof(coerce3)
# coerce character to numeric
(coerce4<-c("1","2","3"))
typeof(coerce4)
(coerce5<-as.numeric(c("1","2","3")))
typeof(coerce5)
#coerce matrix to dataframe
(coerce6<-matrix(1:9,nrow = 3))
is.matrix(coerce6)
(coerce7<-as.data.frame(matrix(1:9,nrow = 3)))
is.data.frame(coerce7)
