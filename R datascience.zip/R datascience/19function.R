x=function(){print("Hello")}
x()
y=function(arg1){arg1**2}
y(4)
z=function(arg1,arg2){loc=arg1+arg2
return(loc)}
z(10,15)
#recursive function
facfoo=function(n){if(n==0){return(1)}
  else return (facfoo(n-1)*n)}
facfoo(5)
facfoo(0)
