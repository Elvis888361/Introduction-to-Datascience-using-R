#what to look for if it is linear , consistent spread,outliers,correlation
library(datasets)
?mtcars
#good to first check univariate distribution
head(mtcars)
hist(mtcars$wt)# for weight histogram
hist(mtcars$mpg)#hist for miles per gram
plot(mtcars$wt,mtcars$mpg)#both in combination
plot(mtcars$wt,mtcars$mpg,
     pch=19,
     cex=1.5,
     col="#cc0000",
     main="MPG as a function of weight of cars",
     xlab="Weight(in 1000 ponds",
     ylab="MPG")
#one of best way of dta visualization of two quantitative dta