# making sammary
library(datasets)
head(iris)
summary(iris$Species)#frequencies for each category of iris
summary(iris$Sepal.Length)#shows the quantitative variable
summary(iris)#entire data frame sammary

