#ad hoc data
#may methods colon,seq,c,scan and rep,<-assignment operator
#colon operator
x1<-0:10#assigns number 0 through 10 to x1
x1
#descending order
x2<-10:0
x2
#seq method sequence
?seq
(x3<-seq(10))# ascending order
(x4<-seq(30,0,by=-3))#specify change in values
#Enter multiple value with C
#c concatenate
?c
x5<-c(5,4,1,6,7,2,2,3,2,8)
x5
#scan
?scan
x6<-scan()
x6
#rep
?rep
x7<-rep(TRUE,5)
x7
# repeats set
x8<-rep(c(TRUE,FALSE),5)
x8
x9<-rep(c(TRUE,FALSE),each=5)
x9